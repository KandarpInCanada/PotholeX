"use client";

export default function Page() {
  return null;
}
